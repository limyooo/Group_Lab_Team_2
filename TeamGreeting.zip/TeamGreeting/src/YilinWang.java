/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author evelyn
 */
public class YilinWang {

    public static void main(String[] args) {
        System.out.println("YilinWang's part is running!");
    }
}

